Alembic migration environment and versions/ — wired up in Step 3 (Database). Exists now so models/ has a clear migration home from day one.
