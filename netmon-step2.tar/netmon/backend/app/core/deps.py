"""Shared dependency-injection type aliases.

Contract: `api/` routers depend on `SettingsDep` (never call `get_settings()`
or `Settings()` directly), so swapping the provider in tests
(`app.dependency_overrides[get_settings] = ...`) affects every router
uniformly. More aliases (DbSessionDep, EventBusDep, ...) land here in
later steps as those subsystems are built.
"""

from __future__ import annotations

from typing import Annotated

from fastapi import Depends

from app.core.config import Settings, get_settings

SettingsDep = Annotated[Settings, Depends(get_settings)]
