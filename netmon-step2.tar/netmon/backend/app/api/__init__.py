"""HTTP/WebSocket entrypoints. Routers only — no business logic.

Contract: functions here parse/validate input (via Pydantic schemas),
call a service, and serialize the response. Never talk to
repositories or models directly, never contain monitoring logic."""
