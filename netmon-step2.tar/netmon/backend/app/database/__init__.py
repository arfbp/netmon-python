"""Database engine/session lifecycle (SQLAlchemy async engine,
sessionmaker, Base declarative class) and Alembic wiring.
Contract: only repositories/ are allowed to import Session usage
patterns from here; services/ receive sessions via DI, they don't
construct them."""
