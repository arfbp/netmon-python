"""Data-access layer. One repository per model, each behind
an abstract interface (Protocol/ABC) so services can be unit-tested
with an in-memory fake instead of a real database. Repositories are
the ONLY layer allowed to write SQLAlchemy queries."""
