"""SQLAlchemy ORM models — one file per aggregate
(ping_history.py, dns_history.py, http_history.py, speed_test.py,
incident.py, traceroute.py, tcp_capture.py, alert.py, setting.py).
Models are persistence-shape only: no business logic, no monitor code."""
