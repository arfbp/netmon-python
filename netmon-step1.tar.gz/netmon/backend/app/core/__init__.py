"""Cross-cutting application concerns: settings, logging setup,
security, dependency-injection providers, and app-wide constants/enums
(e.g. Severity, MonitorType). Nothing here imports from services/
or monitors/ — this package sits below everything else."""
